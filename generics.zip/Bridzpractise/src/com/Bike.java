package com;

public class Bike extends Vehicle{

	public Bike(String numberplate, int speed, int type) {
		super(numberplate, speed, type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculateFuelConsumption() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
