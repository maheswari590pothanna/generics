package com;

public class Car extends Vehicle {
	public Car(String numberplate, int speed, int type) {
		super(numberplate, speed, type);
	}

	@Override
	public double calculateFuelConsumption() {

		return 8 % (100 - speed);
	}
} 
