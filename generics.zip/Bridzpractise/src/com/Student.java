package com;

import java.util.Arrays;

public class Student {
	private int id;
	private String name;
	private Subject[] subjects;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Subject[] getSubjects() {
		return subjects;
	}
	public void setSubjects(Subject[] subjects) {
		this.subjects = subjects;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", subjects=" + Arrays.toString(subjects) + "]";
	}
	
	
	public  int totalsum() {
		int sum=0;
		for(Subject s:subjects) {
			sum=sum+s.getMarks();
		}
		return sum;
	}
	
	
	public double getAverage() {
		return totalsum()/subjects.length;
	}
	
	public boolean result() {
		for(Subject s:subjects) {
			if(s.getMarks()>35) {
				return true;
			}
		}
		return false;
	}
	
	public void display() {
		System.out.println("Student id:"+id);
		System.out.println("student name:"+name);
		
	}
	
	
	
	

}
