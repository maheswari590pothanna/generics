package com;

public abstract class Vehicle {
	String numberplate;
	int speed;
	int type;

	public Vehicle(String numberplate, int speed, int type) {
		super();
		this.numberplate = numberplate;
		this.speed = speed;
		this.type = type;
	}

	public abstract double calculateFuelConsumption();

	public void displayInfo() {
		System.out.println("type of vehicle:" + type);
		System.out.println("speed" + speed + "km/h");
		System.out.println("numberplate" + numberplate);
		System.out.println(calculateFuelConsumption() + "km/h");

	}

}
