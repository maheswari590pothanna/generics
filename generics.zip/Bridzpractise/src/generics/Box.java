package generics;

//📘 Problem:
//Create a generic class Box<T> that can store any type of object.
//
//Requirements:
//
//Methods:
//
//void setValue(T value)
//
//T getValue()
//
//Test with Integer, String, and Double.

public class Box<T> {
	private T value;
	
	
	public void setValue(T value) {
		this.value=value;
	}
	
	public T getValue() {
		return value;
	}
	public static void main(String[] args) {
		Box<String> b=new Box<String>();
		b.setValue("hello");
		System.out.println("the value of the box"+b.getValue());
		
		Box<Integer> bb=new Box<Integer>();
		bb.setValue(999);
		System.out.println(bb.getValue());
		
		Box<Double> d=new Box<Double>();
		d.setValue(3.9);
		System.out.println(d.getValue());
		
		
		
	}

}
