package generics;

public class CountUtils {
	public static <T extends Comparable<T>> int countGreaterThan(T[] array, T element) {
		int count = 0;
		for (T item : array) {
			if (item.compareTo(element) > 0) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {
		Integer[] nums = { 10, 20, 5, 30, 25 };
		System.out.println("Greater than 15: " + CountUtils.countGreaterThan(nums, 15));
	}

}
