package generics;

import java.util.Scanner;

public class Data<T extends Number> {
	
	public double square(T number) {
		double value=number.doubleValue();
		return value *value;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Data<Integer> intval=new Data<>();
		System.out.println(intval.square(sc.nextInt()));
		
		Data<Double> douval=new Data<>();
		System.out.println(douval.square(sc.nextDouble()));
	}
	

}
