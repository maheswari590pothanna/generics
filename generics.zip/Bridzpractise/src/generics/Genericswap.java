package generics;
//2. Generic Method to Swap Elements
//📘 Problem:
//Write a generic method swap(T[] array, int i, int j) that swaps two elements in an array.
//
//Requirements:
//
//Apply to arrays of type Integer, String, and Double.


public class Genericswap {

	public static <T> void swap(T[] array, int i, int j) {
		T temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}

	public static <T> void display(T[] array) {
		for (T item : array) {
			System.out.println(item);
		}
	}

	public static void main(String[] args) {

		Integer[] arr = { 1, 2, 3, 4, 5 };
		System.out.println("Array before swapping values:");
		display(arr);
		swap(arr, 1, 3);
		System.out.println("array after the swapping:");
		display(arr);

		String[] str = { "mahi", "lahari", "peeru" };
		System.out.println("before swapping:");
		display(str);
		swap(str, 0, 2);
		System.out.println("after the swapping:");
		display(str);

	}

}
