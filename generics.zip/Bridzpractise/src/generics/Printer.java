package generics;

import java.util.Arrays;
import java.util.List;

public class Printer {
	public static void printList(List<?> list) {
		for (Object item : list) {
			System.out.println(item);
		}
	}

	public static void main(String[] args) {
		Printer.printList(Arrays.asList("Java", "Python", "C++"));
		Printer.printList(Arrays.asList(1, 2, 3, 4));
	}

}
