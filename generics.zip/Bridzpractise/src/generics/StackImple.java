package generics;

public class StackImple<T> {

	private int maxSize;
	private T[] stackArray;
	private int top;

	public StackImple(int size) {
		this.maxSize = size;
		this.stackArray = (T[]) new Object[size];
		this.top = -1;
	}

	public void push(T item) {
		if (top == maxSize - 1) {
			System.out.println("Stack Overflow! Cannot push " + item);
			return;
		}
		stackArray[++top] = item;
	}

	public T pop() {
		if (isEmpty()) {
			System.out.println("stack is empty");
			return null;
		}
		return stackArray[top--];
	}

	public T peek() {
		if (isEmpty()) {
			System.out.println("Stack is empty!");
			return null;
		}
		return stackArray[top];
	}

	public boolean isEmpty() {
		return top == -1;
	}
}
