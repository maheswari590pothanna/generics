package generics;

public class StackMain {
	    public static void main(String[] args) {
	       
	        StackImple<Integer> intStack = new StackImple<>();
	        intStack.push(10);
	        intStack.push(20);
	        System.out.println("Popped from int stack: " + intStack.pop());

	        // String Stack
	        Stack<String> stringStack = new StackImple<>();
	        stringStack.push("Hello");
	        stringStack.push("World");
	        System.out.println("Top of string stack: " + stringStack.peek());

	        // Character Stack
	        Stack<Character> charStack = new Stack<>();
	        charStack.push('A');
	        charStack.push('B');
	        System.out.println("Popped from char stack: " + charStack.pop());
	    }
	}

}
